#Get BRT output required for Zonation scenarios
memory.limit(size=56000)
load("2_BRT_outputs/outputs.RData")
#loads the BRTs
library(ggplot2)
library(gbm)
library(dplyr)
library(tidyr)
library(raster)
library(maptools)
library(ncdf4)
library(rasterVis)
library(RColorBrewer)
library(zoo)
library(gridExtra)
#The purpose of this script is to show how to obtain
#point counts from the boosted regression trees for Canada
#Warbler in the Al-Pac FMA in northeastern Alberta. The
#point counts along with rasters from the previous script will 
#serve as some of the inputs for Zonation scenarios. 

#We are specifically interested in three items from the BRTs. 
#First, we need a raster of current mean predicted density from 248 BRT
#sample runs, along with a raster of the uncertainty (standard
#deviation) in those estimates for each 250-m pixel.
#We also extracted the locations of known Canada Warbler
#occurrences, with the measured abundance at each location.
#These locations will increase the weight and prioritization
#of those locations for conservation or special management.

#Get Current Mean and SD Density Rasters from "3_getLandisandBBStrajectories" script

#rast2 has been saved as "PresentPredictedDensity_mean" to each Zonation project
#SDpreds has been saved as "PresentPredictedDensity_SD" to each Zonation project

#Get Future Mean and SD Rasters from "4_get_rasters_for Zonation" script

#Once we have the necessary raster inputs, we set up a
#Zonation scenario outside of R and ran it. We then
#process some of the Zonation output inside R to generate
#plots the way we like.

#These is a raster cropped to the Al-Pac FMA that will be used
#to filter Canada Warbler occurrences to just those locations within
#the Landis scenarios.
alpac<-raster("0_data/1_processed/Rasters for Zonation/ZonationMean_CAWA_AB_BaselineFireDrought_0_mortHarvest.tif")

#Now get CAWA point locations used in BRTs to create text file "SSI_CAWA_CH_AB"
SSI_CAWA_CH_AB<-datcombo[,c("X","Y","ABUND")]
str(SSI_CAWA_CH_AB)#123996
SSI_CAWA_CH_AB<-SSI_CAWA_CH_AB[SSI_CAWA_CH_AB$ABUND>0,]
str(SSI_CAWA_CH_AB)#1414
#Now get rid of the points outside the AlPac FMA
extent(alpac)
#class      : Extent 
#xmin       : -1213000 
#xmax       : -881750 
#ymin       : 7357500 
#ymax       : 7685000 
write.csv(SSI_CAWA_CH_AB, file="0_data/1_processed/Zonation Scenarios Run/SSI_CAWA_CH_AB.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file
#remove CAWA occurrences outside of AlPac extent


#The purpose of this script is to process specific outputs
#from each self-contained Zonation scenario that has been 
#run, creating custom-designed plots in R from that output.

#A multipanel plot of predicted densities:
library(raster)
library(sp)
library(sf)
library(viridis)
library(rasterVis)
library(tmap)
library(rgdal)
library(rgeos)
library(dplyr)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer

#province and territory shapefile
provs <-  readOGR("0_data/0_raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#provs <-  readOGR("0_data/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
provsproj<-spTransform(provs, CRSobj = lcc_crs)

#protected areas 
PAs <- readOGR("0_data/0_raw/Protected Areas/CPCAD2019.shp") 
PA.Alberta<-PAs[PAs$LOC_E=="Alberta",]
PAproj <- spTransform(PA.Alberta, CRSobj = lcc_crs) # reproject PA.Alberta to be lcc

#water
water <-  readOGR("0_data/0_raw/openwater/openwater2016_oct2021.shp")
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
waterproj<-spTransform(water, CRSobj = lcc_crs)

#province and territory shapefile
provs <-  readOGR("0_data/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
provsproj<-spTransform(provs, CRSobj = lcc_crs)

#AlPac FMA boundary
AlPac <-  readOGR("0_data/0_raw/ALPAC_FMA/ALPAC_FMA.shp") 
AlPacproj<-spTransform(AlPac, CRSobj = lcc_crs)
#dissolve
AlPacproj$FMA<-"AlPac"
AlPacregion <- gUnaryUnion(AlPacproj, id = AlPacproj@data$FMA)

current.ab<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/PresentPredictedDensity_mean.tif")
current.ab.rp<-projectRaster(current.ab, crs=lcc_crs)
current.2100.ab.best<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/ZonationMean_CAWA_AB_BestCase.tif")
current.2100.ab.best.rp<-projectRaster(current.2100.ab.best, crs=lcc_crs)
current.2100.ab.medium<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/ZonationMean_CAWA_AB_MediumCase.tif")
current.2100.ab.medium.rp<-projectRaster(current.2100.ab.medium, crs=lcc_crs)
current.2100.ab.worst<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/ZonationMean_CAWA_AB_WorstCase.tif")
current.2100.ab.worst.rp<-projectRaster(current.2100.ab.worst, crs=lcc_crs)

iStack<-stack(current.ab.rp, 
              current.2100.ab.best.rp,
              current.2100.ab.medium.rp,
              current.2100.ab.worst.rp)


names(iStack) <- c("a", "b", "c", "d")#rename the files for the panel plot 'names'

#colour ramp for raster
# bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
#                                         "#FFF68F", 
#                                         "#ADFF2F", 
#                                         "greenyellow", 
#                                         "#00CD00", 
#                                         "green3", 
#                                         "mediumturquoise", 
#                                         "#007FFF", 
#                                         "blue", 
#                                         "purple", 
#                                         "red"), space="Lab")

LBDG<-colorRampPalette(c("tan","darkgreen"))
WHDG<-colorRampPalette(c("white","darkgreen"))

#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("3_Zonation_outputs_processed_in_R/MultipanelDensityMaps.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=WHDG) + # color scheme
  #latticeExtra::layer(sp.polygons(waterproj, col="lightblue", fill="lightblue",lwd = 1.5))+ # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlaid
  latticeExtra::layer(sp.lines(PAproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlaid
  latticeExtra::layer(sp.lines(AlPacregion, col="black",lwd = 1.5))
dev.off()


#For the Alberta study area, I will create three sets of maps
#from the Zonation outputs. Each set will contain a panel colouring
#pixels according to their conservation priority on a continuous
#gradient. The second panel will identify all the pixels
#that are required for conservation to maintain the current
#population of Canada Warblers in the study area.

#Current population from mean density raster: 13217 

#The three sets of maps are:
#Best case scenario (Current density + CAWA density in 2100
#under best case scenario)=Baseline Climate/No New Harvest

#Medium case scenario (Current density + CAWA density in 2100
#under medium case scenario)=Baseline Climate/6 % Annual Cut

#Worst case scenario (Current density + CAWA density in 2100
#under worst case scenario)=RCP 4.5/6% annual cut

library(raster)
library(sp)
library(sf)
library(viridis)
library(viridisLite)
library(raster)
library(RColorBrewer)
library(tmap)
library(rgdal)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer


ranksab<-raster("0_data/1_processed/Zonation Scenarios Run/Current Density Only/outputs/CurrentDensityOnly.rank.compressed.tif")
ranksab.rp<-projectRaster(ranksab, crs=lcc_crs)
ranks2100.ab.best<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/outputs/CAWA_AB_BestCase.rank.compressed.tif")
ranks2100.ab.best.rp<-projectRaster(ranks2100.ab.best, crs=lcc_crs)
ranks2100.ab.medium<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/outputs/CAWA_AB_MediumCase.rank.compressed.tif")
ranks2100.ab.medium.rp<-projectRaster(ranks2100.ab.medium, crs=lcc_crs)
ranks2100.ab.worst<-raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/outputs/CAWA_AB_WorstCase.rank.compressed.tif")
ranks2100.ab.worst.rp<-projectRaster(ranks2100.ab.worst, crs=lcc_crs)
iStackB<-stack(ranksab.rp, 
              ranks2100.ab.best.rp,
              ranks2100.ab.medium.rp,
              ranks2100.ab.worst.rp)

names(iStackB) <- c("a", "b", "c", "d")#rename the files for the panel plot 'names'


#setting my trellis themes
library(lattice)
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("3_Zonation_outputs_processed_in_R/MultipanelZonationRankMaps.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=WHDG) + # color scheme
  #latticeExtra::layer(sp.polygons(waterproj, col="lightblue", fill="lightblue",lwd = 1.5))+ # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlaid
  latticeExtra::layer(sp.lines(PAproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlaid
  latticeExtra::layer(sp.lines(AlPacregion, col="black",lwd = 1.5))
dev.off()

############
#example code to create discrete value rasters for figures with CHID identified
#these rasters could then be stacked in the above code for panels. 

#LC1 Current Distribution Only 23 % cutoff
current <- raster("0_data/1_processed/Zonation Scenarios Run/Current Density Only/outputs/CurrentDensityOnly.rank.compressed.tif")
ncell(current)#1735750
ncell(current[!is.na(current)])#816573
#Area: 816573 cells*6.25 ha/cell = 5103581 ha
current.b <- current
current.b[current < (0.23384)] <- 0 
#what land you can lose (~23.28%) before starting to lose habitat for 100 % of current population
current.b[current >= 0.23384] <- 1 
#what land you need to maintain habitat for 100 % of current population
current.b[current >= 0.68457] <- 2 
#what land you need to maintain habitat for 90 % of current population
current.b[current >= 0.81143] <- 3 
#what land you need to maintain habitat for 75 % of current population
current.b[current >= 0.91136] <- 4 
#what land you need to maintain habitat for 50 % of current population
current.b[current >= 0.96732] <- 5 
#what land you need to maintain habitat for 25 % of current population
plot(current.b)

#view
tm_shape(current.b) + tm_raster()
plot(current.b)
writeRaster(current.b, filename="3_Zonation_outputs_processed_in_R/A_perc_popn_range.tif", overwrite=TRUE)

#Best Case Scenario: median estimate 14784.94
#is 41.54 % of current population

#LC3 Baseline Climate No Clearcut
best <- raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/outputs/CAWA_AB_BestCase.rank.compressed.tif")
best.b <- best
best.b[best < 0.98331] <- 0
best.b[best >= 0.98331] <- 4 
#what land you need to maintain habitat for 41.54 (you won't get 50) % of current population
best.b[best > 0.9823] <- 5
#what land you need (100-99.03) to maintain habitat for 25 % of current population

#view
tm_shape(best.b) + tm_raster()
plot(best.b)
writeRaster(best.b, filename="3_Zonation_outputs_processed_in_R/B_perc_popn_range.tif", overwrite=TRUE)

#Medium Case Scenario: median estimate 12597.19
#is 35.39 % of current population

#LC3 Baseline Climate 6% Annual Clearcut 
medium <- raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/outputs/CAWA_AB_MediumCase.rank.compressed.tif")
medium.b <- medium
medium.b[medium < (0.98531)] <- 0
medium.b[medium >= 0.98531] <- 4 
#what land you need to maintain habitat for 35.39 % of current population (you won't get 50) % of current population
medium.b[medium >= 0.99131] <- 5
#what land you need to maintain habitat for 25 % of current population

#view
tm_shape(medium.b) + tm_raster()
plot(medium.b)
writeRaster(medium.b, filename="3_Zonation_outputs_processed_in_R/C_perc_popn_range.tif", overwrite=TRUE)

#Worst Case Scenario: median estimate 10518.1
#is 29.55 % of current population
#To protect 25 % of current population, I need to
#protect 84.60 % of future worst-case population

#LC3 RCP 4.5 High Clearcut
worst <- raster("0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/outputs/CAWA_AB_WorstCase.rank.compressed.tif")
worst.b <- worst
worst.b[worst < 0.98931] <- 0
worst.b[worst >= 0.98931] <- 4 
#what land you need to maintain habitat for 25-50 (you won't get 50) % of current population
worst.b[worst >= 0.99131] <- 5
#what land you need to maintain habitat for 25 % of current population

#view
tm_shape(worst.b) + tm_raster()
plot(worst.b)
writeRaster(worst.b, filename="3_Zonation_outputs_processed_in_R/D_perc_popn_range.tif", overwrite=TRUE)


#projection of iStack: "+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs "
iStackC<-stack(current.b, best.b, medium.b, worst.b)
  
names(iStackC) <- c("a", "b", "c", "d")#rename the files for the panel plot 'names'

#setting my trellis themes
library(lattice)
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

#option of using viridisLite palettes for color-blind-friendly 
#palettes, but the results don't look good
multicols<-cividis(n=5)#choices viridis, cividis, magma, plasma, inferno

#using a set of manually selected colours that will 
#hopefully work for most people
multicols<-colorRampPalette(c("yellow","lightgreen","darkgreen","blue","violet"))

#setwd("D:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional Alberta BRT/Landscape simulation results April 2021/2_outputs/Zonation Scenarios Run/panels in R")
tiff('3_Zonation_outputs_processed_in_R/AlbertaMultipanelZonationOct4percentagecurrent.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackC,
                     margin=FALSE, 
                     # removes the histograms at the margins   
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='right', # location for legend bar              
                     #   height=0.5, width=0.5, at=seq(0,4,1), 
                     #   labels=list(as.character(c("No contribution", "75-100% Popn", "50-75% Popn", "25-50% Popn", "0-25% Popn")), font=10, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=multicols) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(AlPacregion, col="black",lwd = 1.5)) 
dev.off()

multicols<-colorRampPalette(c("yellow","blue"))
multicols(5)
tiff('3_Zonation_outputs_processed_in_R/AlbertaMultipanelZonationOct4percentagecurrent_YellowBlue.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackC,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       height=0.5, width=0.5,
                       labels=list(at=seq(0,4,1), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=multicols) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(AlPacregion, col="black",lwd = 1.5)) 
dev.off()

multicols<-colorRampPalette(c("yellow","darkred"))
multicols(5)
#setwd("D:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional Alberta BRT/Landscape simulation results April 2021/2_outputs/Zonation Scenarios Run/panels in R")
tiff('2_outputs/Zonation Scenarios Run/AlbertaMultipanelZonationOct4percentagecurrent_YellowDarkRed.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackC,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       height=0.5, width=0.5,
                       labels=list(at=seq(0,4,1), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=multicols) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))#+ # extra shapefile data I want overlayed
#latticeExtra::layer(sp.lines(AlPacproj, col="black",lwd = 1.5)) 
# extra shapefile data I want overlayed but won't overlay for unknown reason
dev.off()

heatramp<- colorRampPalette(c("#FFFFFF","#FFFFBF","#FEE090", "#F46D43", "#A50026") ) #set the colours #individual colours for colour ramp from white through yellow and orange to red
y2bramp<-colorRampPalette(c("#FFFFFF","#FFFFBF","#90EE90", "#006400", "#00008B") ) #set the colours #individual colours for colour ramp from white through yellow and green to dark blue

tiff('3_Zonation_outputs_processed_in_R/MultipanelZonationPercentAreas4CurrentPopn.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackC,
                     margin=FALSE, 
                     # removes the histograms at the margins   
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='right', # location for legend bar              
                     #   height=0.5, width=0.5, at=seq(0,4,1), 
                     #   labels=list(as.character(c("No contribution", "75-100% Popn", "50-75% Popn", "25-50% Popn", "0-25% Popn")), font=10, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=y2bramp) + # extra shapefile data I want overlaid
  #latticeExtra::layer(sp.polygons(waterproj, col="lightblue", fill="lightblue",lwd = 1.5))+ # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlaid
  latticeExtra::layer(sp.lines(PAproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlaid
  latticeExtra::layer(sp.lines(AlPacregion, col="black",lwd = 1.5))
dev.off()

#Runtime plots
library(ggplot2)
library(grid)
library(gridExtra)

mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

current.alberta.rt<-read.csv("0_data/1_processed/Zonation Scenarios Run/Current Density Only/outputs/Zonation_current_only_AB.runtimeplot.csv")
plot1<- ggplot(data=current.alberta.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_currentpopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.23384,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 100 % of current population
  geom_vline(xintercept = 0.68457,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 90 % of current population
  geom_vline(xintercept = 0.81143,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 75 % of current population
  geom_vline(xintercept = 0.91136,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 50 % of current population
  geom_vline(xintercept = 0.96732,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 25 % of current population
  labs(x = "Proportion of CAWA range lost in AlPac FMA", y="Proportion of Current Population Left", size=5)+
  annotate("text", x= 0.21, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.665, y = 0,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.77, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.87, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)+
  annotate("text", x= 0.95, y = 0,hjust=0, label = "25 % of current population", size=3, angle=90)

ggsave(plot1, file="3_Zonation_outputs_processed_in_R/Zonation_current_only_AB.runtimeplot.png", units="in", width=10, height=8)

current.2100.alberta.best.rt<-read.csv("0_data/1_processed/Zonation Scenarios Run/Oct 2021 BestCaseScenario/outputs/CAWA_AB_BestCase.runtimeplot.csv")
plot2<- ggplot(data=current.2100.alberta.best.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.98331,  size=0.5, linetype="dashed")+
  #what land you can lose (~98.331) before starting to lose habitat for 41.59 % of current population 
  #(max. proportion of current population in 2100 in best case)
  geom_vline(xintercept = 0.9823,  size=0.5, linetype="dashed")+
  #what land you can lose (~98.23) before starting to lose habitat for 25 % of current population
  labs(x = "Proportion of CAWA range lost in Al-Pac FMA (Best case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.97, y = 0,hjust=0, label = "41.54 % of current population (max possible)", size=3, angle=90)+
  annotate("text", x= 0.99, y = 0,hjust=0, label = "25 % of current population", size=3, angle=90)+xlim(0.75,1)

ggsave(plot2, file="3_Zonation_outputs_processed_in_R/Zonation_current_plus_2100_AB_Best.runtimeplot.png", units="in", width=10, height=8)

current.2100.alberta.medium.rt<-read.csv("0_data/1_processed/Zonation Scenarios Run/Oct 2021 MediumCaseScenario/outputs/CAWA_AB_MediumCase.runtimeplot.csv")
plot3<- ggplot(data=current.2100.alberta.medium.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.98531,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat (5.14%) for 35.39 % of current population in 2100 (max possible)
  geom_vline(xintercept = 0.99131,  size=0.5, linetype="dashed")+
  #what land you can lose (~99.131) and still maintain habitat for 25 % of current population
  labs(x = "Proportion of CAWA range lost in Al-Pac FMA (Medium case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.98, y = 0,hjust=0, label = "35.39 % of current population (max possilbe)", size=3, angle=90)+
  annotate("text", x= 0.995, y = 0,hjust=0, label = "25 % of current population", size=3, angle=90)+xlim(0.75,1)

ggsave(plot3, file="3_Zonation_outputs_processed_in_R/Zonation_current_plus_2100_AB_Medium.png", units="in", width=10, height=8)

current.2100.alberta.worst.rt<-read.csv("0_data/1_processed/Zonation Scenarios Run/Oct 2021 WorstCaseScenario/outputs/CAWA_AB_WorstCase.runtimeplot.csv")
plot4<- ggplot(data=current.2100.alberta.worst.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.98931,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat (98.931) for 29.55 % of current population in 2100 (max possible)
  geom_vline(xintercept = 0.99131,  size=0.5, linetype="dashed")+
  #what land you can lose (~99.131) before starting to lose habitat for 25 % of current population
  labs(x = "Proportion of CAWA range lost in Al-Pac FMA (Worst case)", y="Proportion of Future Population Left", size=5)+
  annotate("text", x= 0.98, y = 0,hjust=0, label = "29.55 % of current population (max possible)", size=3, angle=90)+
  annotate("text", x= 0.995, y = 0,hjust=0, label = "25 % of current population", size=3, angle=90)+xlim(0.75,1)

ggsave(plot4, file="3_Zonation_outputs_processed_in_R/Zonation_current_plus_2100_AB_Worst.runtimeplot.png", units="in", width=10, height=8)

plot5<-grid.arrange(plot1,plot2,plot3,plot4,nrow=2,ncol=2)
ggsave(plot5, file="3_Zonation_outputs_processed_in_R/Zonation_AB.runtimeplots.png", units="in", width=12, height=8)


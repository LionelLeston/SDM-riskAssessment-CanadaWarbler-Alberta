memory.limit(size=560000)
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)

# Preparing data

# Load avian datasets, AB region raster, project and extract data for AB, 
load("0_data/0_raw/BAM_data_package_August2019.RData")
#contains:
#LCC ("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
#offcombo (PKEY, SPECIES, logoffset): visit ID, species name, detection offset of species per visit
#PCcombo (PKEY, SPECIES, ABUND): visit ID, species name, abundance of species per visit
#PKEYcombo (PKEY, SS, YEAR, ARU): visit ID, station ID, year of visit, whether visit is human observer or ARU
#SPP: names of 128 bird species in the data
#SScombo (SS, X, Y): station ID, coordinates in LCC projection
#TAX: taxonomy variables (many)

# offl <- data.table(melt(OFF))
# names(offl) <- c("PKEY","SPECIES","logoffset")
# offl$SPECIES <- as.character(offl$SPECIES)
# offl$PKEY <-as.character(offl$PKEY)
# rm(OFF)


eco <- raster("0_data/0_raw/spatial/albertaeco1.tif") 
alberta <- raster("0_data/0_raw/spatial/AlbertaLCC.tif")
alberta<-projectRaster(alberta,crs=LCC)
plot(alberta)

# Load Beaudoin layers (2011 and 2001), crop and mask for AB, save as rasters
#2011 files available from https://drive.google.com/drive/folders/13ptMESBpgMivNDavVD-R0QoVF1Gbk2AX (with permission)
b2011 <- list.files("0_data/0_raw/Beaudoin/2011/",pattern="tif$")
#setwd("0_data/0_raw/Beaudoin/2011/")
bs2011 <- stack(raster(paste0("0_data/0_raw/Beaudoin/2011/",b2011[1])))
for (i in 2:length(b2011)) { bs2011 <- addLayer(bs2011, raster(paste0("0_data/0_raw/Beaudoin/2011/",b2011[i])))}
names(bs2011) <- gsub("NFI_MODIS250m_2011_kNN_","",names(bs2011))
abs2011 <- crop(bs2011,alberta)
abs2011 <- mask(abs2011,alberta)
writeRaster(abs2011, filename="0_data/0_raw/Beaudoin/2011/Processed/AB/abs2011_250m.grd", format="raster",overwrite=TRUE)

#2001 files available from https://drive.google.com/drive/folders/1jFgfHULI6yngGqvBh_uHXMaH-hDJMtIK (with permission)
b2001 <- list.files("0_data/0_raw/Beaudoin/2001/",pattern="tif$")
#setwd("0_data/0_raw/Beaudoin/2001/")
bs2001 <- stack(raster(paste0("0_data/0_raw/Beaudoin/2001/",b2001[1])))
for (i in 2:length(b2001)) { bs2001 <- addLayer(bs2001, raster(paste0("0_data/0_raw/Beaudoin/2001/",b2001[i])))}
names(bs2001) <- gsub("NFI_MODIS250m_2001_kNN_","",names(bs2001))
abs2001 <- crop(bs2001,alberta)
abs2001<-mask(abs2001,alberta)
writeRaster(abs2001, filename="0_data/0_raw/Beaudoin/2001/Processed/AB/abs2001_250m.grd", format="raster",overwrite=TRUE)

# obtain weighted sums of neighourhood cells using Gaussian filter with sigma=250, and 750m for Beaudoin and CTI layers, save outputs as rasters
abs2011<-brick("0_data/0_raw/Beaudoin/2011/Processed/AB/abs2011_250m.grd")

#Beaudoin 2011
## sigma = 250m
fw250<-focalWeight(x=abs2011,d=250,type="Gauss")
abs2011_Gauss250<-stack(focal(abs2011[[1]],w=fw250,na.rm=TRUE))
names(abs2011_Gauss250)<-names(abs2011)[[1]]
for(i in 2:nlayers(abs2011)){
 abs2011_Gauss250<-addLayer(abs2011_Gauss250,focal(abs2011[[i]],w=fw250,na.rm=TRUE))
 names(abs2011_Gauss250)[i]<-names(abs2011)[[i]]
}
abs2011_Gauss250<-brick(abs2011_Gauss250)
writeRaster(abs2011_Gauss250, filename="0_data/0_raw/Beaudoin/2011/Processed/AB/abs2011_250_Gauss250m.grd", format="raster",overwrite=TRUE)
#abs2011_Gauss250<-brick("D:/Beaudoin/2011/Processed/AB/abs2011_250_Gauss250m.grd")

## sigma = 750m
fw750<-focalWeight(x=abs2011,d=750,type="Gauss")
abs2011_Gauss750<-brick(focal(abs2011[[1]],w=fw750,na.rm=TRUE))
names(abs2011_Gauss750)<-names(abs2011)[[1]]
for(i in 2:nlayers(abs2011)){
 abs2011_Gauss750<-addLayer(abs2011_Gauss750,focal(abs2011[[i]],w=fw750,na.rm=TRUE))
 names(abs2011_Gauss750)[i]<-names(abs2011)[[i]]
}
abs2011_Gauss750<-brick(abs2011_Gauss750)
writeRaster(abs2011_Gauss750, filename="0_data/0_raw/Beaudoin/2011/Processed/AB/abs2011_250_Gauss750m.grd", format="raster",overwrite=TRUE)
#abs2011_Gauss750<-brick("D:/Beaudoin/2011/Processed/AB/abs2011_250_Gauss750m.grd")
rm(abs2011, abs2011_Gauss250, abs2011_Gauss750)
gc()

#Beaudoin 2001
abs2001<-brick("0_data/0_raw/Beaudoin/2001/Processed/AB/abs2001_250m.grd")
## sigma = 250m
abs2001_Gauss250<-stack(focal(abs2001[[1]],w=fw250,na.rm=TRUE))
names(abs2001_Gauss250)<-names(abs2001)[[1]]
for(i in 2:nlayers(abs2001)){
 abs2001_Gauss250<-addLayer(abs2001_Gauss250,focal(abs2001[[i]],w=fw250,na.rm=TRUE))
 names(abs2001_Gauss250)[i]<-names(abs2001)[[i]]
}
abs2001_Gauss250<-brick(abs2001_Gauss250)
writeRaster(abs2001_Gauss250, filename="0_data/0_raw/Beaudoin/2001/Processed/AB/abs2001_250_Gauss250m.grd", format="raster",overwrite=TRUE)


# ## sigma = 750m
abs2001_Gauss750<-brick(focal(abs2001[[1]],w=fw750,na.rm=TRUE))
names(abs2001_Gauss750)<-names(abs2001)[[1]]
for(i in 2:nlayers(abs2001)){
 abs2001_Gauss750<-addLayer(abs2001_Gauss750,focal(abs2001[[i]],w=fw750,na.rm=TRUE))
 names(abs2001_Gauss750)[i]<-names(abs2001)[[i]]
}
abs2001_Gauss750<-brick(abs2001_Gauss750)
writeRaster(abs2001_Gauss750, filename="0_data/0_raw/Beaudoin/2001/Processed/AB/abs2001_250_Gauss750m.grd", format="raster",overwrite=TRUE)

# cti data
cti100<-raster("0_data/0_raw/ABTerrainNielsen/ABTerrainNielsen/100-m/cti.asc")
cti100<-projectRaster(cti100,crs=LCC)
cti250<-resample(cti100,alberta)
writeRaster(cti250, filename="0_data/0_raw/ABTerrainNielsen/ABTerrainNielsen/250-m/cti.asc", format="ascii",overwrite=TRUE)

cti250_Gauss250<-focal(cti250,w=fw250,na.rm=TRUE)
cti250_Gauss750<-focal(cti250,w=fw750,na.rm=TRUE)

writeRaster(cti250_Gauss250, filename="0_data/0_raw/ABTerrainNielsen/ABTerrainNielsen/250-m/Processed/cti250_Gauss250m.asc", format="ascii",overwrite=TRUE)
writeRaster(cti250_Gauss750, filename="0_data/0_raw/ABTerrainNielsen/ABTerrainNielsen/250-m/Processed/cti250_Gauss750m.asc", format="ascii",overwrite=TRUE)


rm(cti100)
gc()

#In case any of these layers were removed before cleaning up memory
#or you are continuing this script on another day.
abs2011<-brick("0_data/0_raw/Beaudoin/2011/Processed/AB/abs2011_250m.grd")
abs2011_Gauss250<-brick("0_data/0_raw/Beaudoin/2011/Processed/AB/abs2011_250_Gauss250m.grd")
abs2011_Gauss750<-brick("0_data/0_raw/Beaudoin/2011/Processed/AB/abs2011_250_Gauss750m.grd")
abs2001<-brick("0_data/0_raw/Beaudoin/2001/Processed/AB/abs2001_250m.grd")
abs2001_Gauss250<-brick("0_data/0_raw/Beaudoin/2001/Processed/AB/abs2001_250_Gauss250m.grd")
abs2001_Gauss750<-brick("0_data/0_raw/Beaudoin/2001/Processed/AB/abs2001_250_Gauss750m.grd")
cti250<-raster("0_data/0_raw/ABTerrainNielsen/ABTerrainNielsen/250-m/cti.asc")
cti250_Gauss250<-raster("0_data/0_raw/ABTerrainNielsen/ABTerrainNielsen/250-m/Processed/cti250_Gauss250m.asc")
cti250_Gauss750<-raster("0_data/0_raw/ABTerrainNielsen/ABTerrainNielsen/250-m/Processed/cti250_Gauss750m.asc")

# Human Footprint data- upload and resample to 250m resolution to match other layers, and attach to abs2011
HF<-list.files("0_data/0_raw/ABMIstuff/",pattern = "tif$")
#setwd("D:/ABMIstuff")
for(i in 1:length(HF)){ 
  HFlayer<-raster(paste0("0_data/0_raw/ABMIstuff/",HF[i]))
  HFlayer<-resample(HFlayer,alberta)
  abs2011 <- addLayer(abs2011, HFlayer)
  names(abs2011)[nlayers(abs2011)] <- gsub("_AB_1km","",names(HFlayer))
}


# water and "lake edge density"
wat <- raster("0_data/0_raw/wat2011_lcc1/wat2011_lcc1.tif")
watAB<- crop(wat,alberta)
watAB<- mask(watAB,abs2011[[1]])

fw250<-focalWeight(x=abs2011,d=250,type="Gauss")
watAB_Gauss250<-focal(watAB,w=fw250,na.rm=TRUE)
watAB_Gauss250[which(is.nan(getValues(watAB_Gauss250)))]<-NA

fw750<-focalWeight(x=abs2011,d=750,type="Gauss")
watAB_Gauss750<-focal(watAB,w=fw750,na.rm=TRUE)
watAB_Gauss750[which(is.nan(getValues(watAB_Gauss750)))]<-NA

# climate data- upload and resample to 250m resolution to match other layers, and attach to abs2011
#climateAW2010 <- list.files("D:/ClimateAdaptWest/baseline19812010/",pattern="asc$")
#setwd("D:/ClimateAdaptWest/baseline19812010/")
#clim2010 <- stack(raster(climateAW2010[1]))
#for (i in 2:length(climateAW2010)) { clim2010 <- addLayer(clim2010, raster(climateAW2010[i]))}
#proj4string(clim2010)<-LCC
#aclim2010 <- crop(clim2010,abs2011)
#aclim2010<-resample(clim2010,abs2011)
#aclim2010<-mask(aclim2010,abs2011$LandCover_NonVeg_v1)
 
#writeRaster(aclim2010, filename="D:/ClimateAdaptWest/baseline19812010/Processed/AB/aclim2010.grd", format="raster",overwrite=TRUE)
#aclim2010<-stack("D:/ClimateAdaptWest/baseline19812010/Processed/AB/aclim2010.grd")

#for(i in 1:length(names(aclim2010))){ 
#  abs2011 <- addLayer(abs2011, aclim2010[[i]])
#  names(abs2011)[nlayers(abs2011)] <- names(aclim2010[[i]])
#}

# put together prediction rasterstack
## need to update names of layers with Gaussian filters first to differentiate them
for(i in 1:nlayers(abs2001_Gauss250)){
  names(abs2001_Gauss250)[i] <- paste(names(abs2001_Gauss250)[i],"_Gauss250",sep="")
  names(abs2001_Gauss750)[i] <- paste(names(abs2001_Gauss750)[i],"_Gauss750",sep="")
  names(abs2011_Gauss250)[i] <- paste(names(abs2011_Gauss250)[i],"_Gauss250",sep="")
  names(abs2011_Gauss750)[i] <- paste(names(abs2011_Gauss750)[i],"_Gauss750",sep="")
}

names(cti250) <- "cti250"
names(cti250_Gauss250) <- "cti250_Gauss250"
names(cti250_Gauss750) <- "cti250_Gauss750"

names(watAB) <- "watAB"
names(watAB_Gauss250) <- "watAB_Gauss250"
names(watAB_Gauss750) <- "watAB_Gauss750"

pred_abs_2011<-stack(abs2011,abs2011_Gauss250,abs2011_Gauss750,cti250,cti250_Gauss250,cti250_Gauss750,watAB, watAB_Gauss250, watAB_Gauss750,quick=TRUE)

ARU<-raster(extent(pred_abs_2011),crs=LCC,resolution=res(pred_abs_2011),vals=0)
names(ARU)<-"ARU"

pred_abs_2011<-stack(abs2011,abs2011_Gauss250,abs2011_Gauss750,cti250,cti250_Gauss250,cti250_Gauss750,watAB, watAB_Gauss250, watAB_Gauss750, ARU,quick=TRUE)
#pred_abs_2011<-stack(pred_abs_2011,ARU)
writeRaster(pred_abs_2011, filename="0_data/1_processed/prediction dataset/abs2011_250m.grd", format="raster",overwrite=TRUE)

ABgridfile<-brick("D:/CWS Wood Thrush Contract/CHID previous work Francisco/CHID regional Alberta BRT/prediction dataset/AB2011_250m.grd")
# Extracting data from rasters for surveyed locations (ABSS)
## 2011

ABSS<-SpatialPointsDataFrame(coords=SScombo[,2:3],data=SScombo, proj4string = LCC)

ab_shp<-readOGR("0_data/0_raw/spatial","AB_eco1") # read in a shapefile of Alberta with which to crop the SScombo spatial df. cannot use raster as it will crop by raster extent, not the province extent
ab_shp<-spTransform(ab_shp,LCC)

ABSS<-crop(ABSS,ab_shp)
ABSS<-ABSS@data
ABSS

dat2011 <- cbind(ABSS, extract(abs2011,as.matrix(cbind(ABSS$X,ABSS$Y)))) # includes Beaudoin layers (250m, no Gaussian filter), HF 

for(i in 1:nlayers(abs2011_Gauss250)){
  dat2011 <- cbind(dat2011, extract(abs2011_Gauss250[[i]],as.matrix(cbind(ABSS$X,ABSS$Y)))) # includes Beaudoin layers with Gaussian filter sigma=250m
  names(dat2011)[ncol(dat2011)] <- names(abs2011_Gauss250)[i]
}

for(i in 1:nlayers(abs2011_Gauss750)){
  dat2011 <- cbind(dat2011, extract(abs2011_Gauss750[[i]],as.matrix(cbind(ABSS$X,ABSS$Y)))) # includes Beaudoin layers with Gaussian filter sigma=750m
  names(dat2011)[ncol(dat2011)] <- names(abs2011_Gauss750)[i]
}

dat2011<-cbind(dat2011,extract(cti250,as.matrix(cbind(dat2011$X,dat2011$Y)))) # includes cti 250m resolution data
names(dat2011)[ncol(dat2011)] <- "cti250"

dat2011<-cbind(dat2011,extract(cti250_Gauss250,as.matrix(cbind(dat2011$X,dat2011$Y)))) # includes cti 250m resolution data, Gaussian filter sigma=250m
names(dat2011)[ncol(dat2011)] <- "cti250_Gauss250"

dat2011<-cbind(dat2011,extract(cti250_Gauss750,as.matrix(cbind(dat2011$X,dat2011$Y)))) # includes cti 250m resolution data, Gaussian filter sigma=750m
names(dat2011)[ncol(dat2011)] <- "cti250_Gauss750"

dat2011<-cbind(dat2011,extract(watAB,as.matrix(cbind(dat2011$X,dat2011$Y)))) # includes wat 250m resolution data
names(dat2011)[ncol(dat2011)] <- "watAB"

dat2011<-cbind(dat2011,extract(watAB_Gauss250,as.matrix(cbind(dat2011$X,dat2011$Y)))) # includes wat 250m resolution data, Gaussian filter sigma=250m
names(dat2011)[ncol(dat2011)] <- "watAB_Gauss250"

dat2011<-cbind(dat2011,extract(watAB_Gauss750,as.matrix(cbind(dat2011$X,dat2011$Y)))) # includes wat 250m resolution data, Gaussian filter sigma=750m
names(dat2011)[ncol(dat2011)] <- "watAB_Gauss750"

dat2011 <-cbind(dat2011,extract(eco,as.matrix(cbind(dat2011$X,dat2011$Y)))) # includes ecoregions layer
names(dat2011)[ncol(dat2011)] <- "eco"

### set up weight matrix for SS, and calculate weight values for each row in dat2011
r2 <- abs2011[[1]]
samprast2011 <- rasterize(cbind(dat2011$X,dat2011$Y), r2, field=1)
sampsum25 <- focal(samprast2011, w=matrix(1/25, nc=5, nr=5), na.rm=TRUE)

dat2011 <- cbind(dat2011,extract(sampsum25,as.matrix(cbind(dat2011$X,dat2011$Y))))
names(dat2011)[ncol(dat2011)] <- "sampsum25"
dat2011$wt <- 1/dat2011$sampsum25

dat2011$SS <- as.character(dat2011$SS)
# dat2011$PCODE <- as.character(dat2011$PCODE)
# dat2011<-dat2011[,-c(25:43)] # remove columns with climate data (from avian dataset, since using Adaptwest Climate data instead)

#setwd("D:/CHID regional Alberta BRT/")
write.csv(dat2011,"0_data/1_processed/ABdat2011.csv")

## 2001
dat2001 <- cbind(ABSS, extract(abs2001,as.matrix(cbind(ABSS$X,ABSS$Y)))) # includes Beaudoin layers (250m, no Gaussian filter), HF and climate

for(i in which(names(abs2011)=="CultivationCrop"):which(names(abs2011)=="TransmissionLine") ) { # copy human footprint  data from dat2011
  dat2001<-cbind(dat2001,extract(abs2011[[i]],as.matrix(cbind(ABSS$X,ABSS$Y))))
  names(dat2001)[ncol(dat2001)] <- names(abs2011)[[i]]
}#replaced "CultivationAbandoned" with "CultivationCrop"

for(i in 1:nlayers(abs2001_Gauss250)){
  dat2001 <- cbind(dat2001, extract(abs2001_Gauss250[[i]],as.matrix(cbind(ABSS$X,ABSS$Y)))) # includes Beaudoin layers with Gaussian filter sigma=250m
  names(dat2001)[ncol(dat2001)] <- names(abs2001_Gauss250)[i]
}

for(i in 1:nlayers(abs2001_Gauss750)){
  dat2001 <- cbind(dat2001, extract(abs2001_Gauss750[[i]],as.matrix(cbind(ABSS$X,ABSS$Y)))) # includes Beaudoin layers with Gaussian filter sigma=750m
  names(dat2001)[ncol(dat2001)] <- names(abs2001_Gauss750)[i]
}

dat2001<-cbind(dat2001,extract(cti250,as.matrix(cbind(dat2001$X,dat2001$Y)))) # includes cti 250m resolution data
names(dat2001)[ncol(dat2001)] <- "cti250"

dat2001<-cbind(dat2001,extract(cti250_Gauss250,as.matrix(cbind(dat2001$X,dat2001$Y)))) # includes cti 250m resolution data, Gaussian filter sigma=250m
names(dat2001)[ncol(dat2001)] <- "cti250_Gauss250"

dat2001<-cbind(dat2001,extract(cti250_Gauss750,as.matrix(cbind(dat2001$X,dat2001$Y)))) # includes cti 250m resolution data, Gaussian filter sigma=750m
names(dat2001)[ncol(dat2001)] <- "cti250_Gauss750"

dat2001<-cbind(dat2001,extract(watAB,as.matrix(cbind(dat2001$X,dat2001$Y)))) # includes wat 250m resolution data
names(dat2001)[ncol(dat2001)] <- "watAB"

dat2001<-cbind(dat2001,extract(watAB_Gauss250,as.matrix(cbind(dat2001$X,dat2001$Y)))) # includes wat 250m resolution data, Gaussian filter sigma=250m
names(dat2001)[ncol(dat2001)] <- "watAB_Gauss250"

dat2001<-cbind(dat2001,extract(watAB_Gauss750,as.matrix(cbind(dat2001$X,dat2001$Y)))) # includes wat 250m resolution data, Gaussian filter sigma=750m
names(dat2001)[ncol(dat2001)] <- "watAB_Gauss750"

dat2001 <-cbind(dat2001,extract(eco,as.matrix(cbind(dat2001$X,dat2001$Y)))) # includes ecoregions layer
names(dat2001)[ncol(dat2001)] <- "eco"

### set up weight matrix for SS, and calculate weight values for each row in dat2001
samprast2001 <- rasterize(cbind(dat2001$X,dat2001$Y), r2, field=1)
sampsum25 <- focal(samprast2001, w=matrix(1/25, nc=5, nr=5), na.rm=TRUE)
dat2001 <- cbind(dat2001,extract(sampsum25,as.matrix(cbind(dat2001$X,dat2001$Y))))
names(dat2001)[ncol(dat2001)] <- "sampsum25"
dat2001$wt <- 1/dat2001$sampsum25

dat2001$SS <- as.character(dat2001$SS)
# dat2001$PCODE <- as.character(dat2001$PCODE)
# dat2001<-dat2001[,-c(25:43)] # remove columns with climate data (from avian dataset, since using Adaptwest Climate data instead)
write.csv(dat2001,"0_data/1_processed/ABdat2001.csv")


# Prepare point count data for each SS and aggregate for 2001 and 2011.


# PC <- inner_join(PCTBL,PKEY[,1:8],by=c("PKEY","SS"))[,-1]
# colnames(PC)[10]<-"PCODE"
# PC <- inner_join(PC,SS@data[,c(2,5)],by="SS")
# ABPC <- PC[PC$JURS=="AB",]

PC<-inner_join(PCcombo,PKEYcombo,by=c("PKEY"))
PC<-inner_join(PC,SScombo,by="SS")
names(PC)

ABPC <- PC[which(PC$SS%in%ABSS$SS),]

ABPC$SS <- as.character(ABPC$SS)
ABPC$PKEY <- as.character(ABPC$PKEY)
# ABPC$PCODE <- as.character(ABPC$PCODE)
ABPC$SPECIES <- as.character(ABPC$SPECIES)
ABPC2001 <- ABPC[ABPC$YEAR < 2006,] #n=412232
ABPC2011 <- ABPC[ABPC$YEAR > 2005,] #n=493883
survey2001 <- aggregate(ABPC2001$ABUND, by=list("PKEY"=ABPC2001$PKEY,"SS"=ABPC2001$SS,"ARU"=ABPC2001$ARU), FUN=sum) #n=69052
survey2011 <- aggregate(ABPC2011$ABUND, by=list("PKEY"=ABPC2011$PKEY,"SS"=ABPC2011$SS,"ARU"=ABPC2011$ARU), FUN=sum) #n=54941

speclist<-levels(as.factor(offcombo$SPECIES))

save.image("0_data/1_processed/data_pack_full.RData")

rm(list=setdiff(ls(),c("pred_abs_2011","LCC","speclist","offcombo","ABPC2001","survey2001","dat2001","ABPC2011","survey2011","dat2011")))
gc()
save.image("0_data/1_processed/data_pack.RData")

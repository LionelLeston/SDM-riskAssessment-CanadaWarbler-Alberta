#The purpose of this script is to generate box
#and line plots showing predicted Canada Warbler 
#abundance over time under different Landis-II
#scenarios in the Al-Pac FMA in northeastern Alberta.

#Note: there are mean density predictions for each 
#simulation run X time step X scenario, but there 
#currently are not mean density predictions for each
#BRT run X scenario X time step X simulation run

#So the estimates of uncertainty implied in these 
#box and line plots are based on 5 means rather
#than 5 X 250 sets of predictions. True uncertainty
#is probably higher.
load("0_data/1_processed/DensityTotal.df.RData")
load("0_data/1_processed/Prediction rasters 2100/birddensityr_meansd_BS_ALPAC_baseline_BaselineFireDrought_0_mortHarvest_1_2100_CAWA.RData")
sizearea<-ncell(rasterstack_meansd$mean[!is.na(rasterstack_meansd$mean)])
sizearea
#[1] 816581 = number of 250-m cells in Landis Alberta simulations
head(DensityTotal.df)

DensityTotal.df$Popsize<-DensityTotal.df$MeanDensity*sizearea*6.25

saveRDS(DensityTotal.df,"2_BRT_outputs/selected_scales_new/bbs and landis trends/bootstrap_predictions2100.R")
write.csv(DensityTotal.df, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/bootstrap_predictions2100.csv")

#Make a box plot showing projected populations by 2100 under different scenarios
popproj2000.2200<-read.csv("2_BRT_outputs/selected_scales_new/bbs and landis trends/bootstrap_predictions2100.csv", header=TRUE)
library(ggplot2)
library(grid)
library(gridExtra)
library(viridis)
library(dplyr)
library(tidyr)

my.theme <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_text(size=8),
        axis.text.y=element_text(size=8),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

my.theme.Xoff <- theme_classic() +
  theme(text=element_text(size=8, family="Arial"),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=8),
        axis.title.x=element_blank(),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

str(popproj2000.2200)
#'data.frame':	1260 obs. of  10 variables:
# $ X               : int  1 2 3 4 5 6 7 8 9 10 ...
# $ scenario        : chr  "baseline" "baseline" "baseline" "baseline" ...
# $ treatment       : chr  "BaselineFireDrought_0_mortHarvest" "BaselineFireDrought_0_mortHarvest" "BaselineFireDrought_0_mortHarvest" "BaselineFireDrought_0_mortHarvest" ...
# $ replicate       : int  1 1 1 1 1 1 1 1 1 1 ...
# $ Year            : int  2000 2010 2020 2030 2040 2050 2060 2070 2080 2090 ...
# $ Species         : chr  "CAWA" "CAWA" "CAWA" "CAWA" ...
# $ MeanDensity     : num  0.00247 0.00253 0.00258 0.00262 0.00269 ...
# $ FireTreatment   : chr  "BaselineFire" "BaselineFire" "BaselineFire" "BaselineFire" ...
# $ HarvestTreatment: chr  "Drought_0_mortHarvest" "Drought_0_mortHarvest" "Drought_0_mortHarvest" "Drought_0_mortHarvest" ...
# $ Popsize         : num  12581 12899 13167 13378 13735 ...
levels(as.factor(popproj2000.2200$HarvestTreatment))
#"Drought_0_mortHarvest" "Drought_3_mortHarvest" "Drought_6_mortHarvest" 

#Recode harvest
popproj2000.2200$HarvestRecode<-NA
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="Drought_0_mortHarvest"]<-"No Harvest"
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="Drought_3_mortHarvest"]<-"3 % Cut"
popproj2000.2200$HarvestRecode[popproj2000.2200$HarvestTreatment=="Drought_6_mortHarvest"]<-"6 % Cut"
levels(as.factor(popproj2000.2200$HarvestRecode))
#Relevel harvest code according to percent biomass removed by harvest
popproj2000.2200$HarvestRecode<-as.factor(popproj2000.2200$HarvestRecode)
popproj2000.2200$HarvestRecode<-factor(popproj2000.2200$HarvestRecode, levels=c("No Harvest","3 % Cut","6 % Cut"))
levels(popproj2000.2200$HarvestRecode)


levels(as.factor(popproj2000.2200$FireTreatment))#2
#"BaselineFire"  "ProjectedFire"
levels(as.factor(popproj2000.2200$treatment))#12 (fire*harvest)
#[1] "BaselineFireDrought_0_mortHarvest"       
#[2] "BaselineFireDrought_3_mortHarvest"       
#[3] "BaselineFireDrought_6_mortHarvest"       
#[4] "GrowthProjectedFireDrought_0_mortHarvest"
#[5] "GrowthProjectedFireDrought_3_mortHarvest"
#[6] "GrowthProjectedFireDrought_6_mortHarvest" 
levels(as.factor(popproj2000.2200$scenario))#4 (climate)
#"baseline" "RCP26"    "RCP45"    "RCP85"

#there are 24 scenarios: fire treatment is "baseline" under baseline
#scenario and "projected" under RCP 2.6, RCP 4.5, and RCP 8.5
# grouped boxplot

#remove RCP26
popproj2100<-popproj2000.2200[!popproj2000.2200$scenario=="RCP26",]
popproj2100<-popproj2100[!popproj2100$scenario=="RCP26",]

P1<-ggplot(popproj2100, aes(x=HarvestRecode, y=Popsize, col=scenario, fill=scenario)) + 
  geom_boxplot()+my.theme+xlab("Harvest Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate Scenario")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE)
ggsave(P1, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2100.box.harvestXclimateL.png", units="in", width=10, height=4)


P2<-ggplot(popproj2100, aes(x=scenario, y=Popsize, col=HarvestRecode, fill=HarvestRecode)) + 
  geom_boxplot()+my.theme+xlab("Climate Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Harvest Scenario")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE)
ggsave(P2, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2100.box.climateXharvestL.png", units="in", width=10, height=4)


P3<-ggplot(popproj2100, aes(x=HarvestRecode, y=Popsize, col=HarvestRecode, fill=HarvestRecode)) + 
  geom_boxplot()+my.theme+xlab("Harvest Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE)+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  facet_wrap(~scenario)+
  theme(legend.position = "none")
ggsave(P3, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2100.facet.harvestXclimateF.png", units="in", width=10, height=4)


P4<-ggplot(popproj2100, aes(x=scenario, y=Popsize, col=scenario, fill=scenario)) + 
  geom_boxplot()+my.theme+xlab("Climate Scenario")+
  ylab("Projected 2100 Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE)+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  facet_wrap(~HarvestRecode)+
  theme(legend.position = "none")
ggsave(P4, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2100.facet.climateXharvestF.png", units="in", width=10, height=4)

#Summarize population projections in writing: median, mean, CI
pop.summ<-popproj2100 %>%
  group_by(HarvestRecode,scenario) %>%
  summarise(Median=median(Popsize),
            Mean=mean(Popsize))#,
            #Stdev=sd(Popsize),  #DO NOT USE THESE ESTIMATES OF UNCERTAINTY: THEY ONLY
            #Stderr=Stdev/sqrt(250),  #ACCOUNT FOR UNCERTAINTY IN THE MEANS, NOT THE
            #CI.05=Mean-1.96*Stderr,   #250 BOOTSTRAP PREDICTIONS FOR EACH YEAR AND SCENARIO
            #CI.95=Mean+1.96*Stderr,   #IN EACH SIMULATION RUN
            #BCI.05=quantile(Popsize, 0.05),
            #BCI.95=quantile(Popsize, 0.95))
pop.summ<-data.frame(pop.summ)
write.csv(pop.summ, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2100.PopnSummary.csv")

#Make line plots tracking population change from 2000 to 2200 (using brt5 results, not the bootstrapped model coefficients)

#To do without RCP 26
data<-popproj2000.2200[!popproj2000.2200$scenario=="RCP26",]

P1<-ggplot(data, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(HarvestRecode~scenario)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(P1, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2000-2200.line.harvestRowXclimateCol.png", units="in", width=10, height=8)

P2<-ggplot(data, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(scenario~HarvestRecode)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(P2, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2000-2200.line.harvestColXclimateRow.png", units="in", width=10, height=8)

data2<-data[!data$Year>2100,]

P3<-ggplot(data2, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(HarvestRecode~scenario)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(P3, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2000-2100.line.harvestRowXclimateCol.png", units="in", width=10, height=8)

P4<-ggplot(data2, aes(x=Year, y=Popsize, col=scenario, fill=scenario)) + 
  geom_line()+  my.theme+xlab("Year")+
  ylab("Population")+ 
  scale_color_viridis(discrete=TRUE)+
  scale_fill_viridis(discrete=TRUE, name="Climate")+ 
  theme(axis.text.x=element_text(angle=90,hjust=1))+
  guides(col=FALSE, fill=FALSE)+facet_grid(scenario~HarvestRecode)+ 
  stat_smooth(method = "glm", formula = y ~ s(x), size = 1)

ggsave(P4, file="2_BRT_outputs/selected_scales_new/bbs and landis trends/CAWA2000-2100.line.harvestColXclimateRow.png", units="in", width=10, height=8)
